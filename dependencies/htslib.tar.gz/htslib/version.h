#define HTS_VERSION_TEXT "1.19.1-22-g7d3efee7"
