/*
* bfileReaderDep contains some general methods for reading and handling big data.
* These methods include can read a column or some target columns from an input
* file (delimited file which can be also gz compressed). Filtering can also be
* be done for both string (regex) and double data types. For regex search,
* more than one column can be used for filtering.

* Oveis Jamialahmadi, July 2021. GU.
*/

import java.nio.file.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Collectors;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.io.FileInputStream;
import java.util.regex.Pattern;
import java.util.function.*;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.InputStream;
import java.util.stream.IntStream;
import java.io.BufferedInputStream;
import java.util.stream.Stream;
import java.util.concurrent.atomic.AtomicInteger;

public class bFileReaderDep {

	// only accepts gz or delimited files
	static private BufferedReader openFile(String filename) throws IOException {
		try{
			String fileExt = filename.substring(filename.lastIndexOf(".") + 1);
			BufferedReader br = null;

			//try{
				if (fileExt.equals("gz")){
					FileInputStream fis = new FileInputStream(filename);
					GZIPInputStream gis = new GZIPInputStream(fis);
					InputStreamReader isr = new InputStreamReader(gis);
					br = new BufferedReader(isr);
				} else {
					br = Files.newBufferedReader(Paths.get(filename));
					// System.out.println("only txt or gz file type is allowed!"); // is there a better way to handle this?
				}
				System.gc();
				return br;
			//} finally{
			//	br.close();
			//}
		}

		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}

	// read whole file content
	static public char[] readAll(String filename, String delim, Integer skip, String bench) throws IOException{
		try(BufferedReader br = openFile(filename)){
			try{
				if (bench.equals("s")){
					List<String> alist = br.lines()
					.skip(skip).collect(Collectors.toList());
					br.close();
					return alist.stream().collect(Collectors.joining(delim)).toCharArray();
				} else if (bench.equals("sp")) {
					List<String> alist = br.lines().parallel()
					.skip(skip).collect(Collectors.toList());
					br.close();
					return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();
				}
				System.gc();
			} finally{
				System.gc();
				br.close();
			}
		}
		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}

	// original readAll
	static public String[] readAll2(String filename, Integer skip, String bench) throws IOException{
		try(BufferedReader br = openFile(filename)){
			try{
				if (bench.equals("s")){
					List<String> alist = br.lines()
					.skip(skip).collect(Collectors.toList());
					br.close();
					return alist.toArray(new String[0]);
				} else if (bench.equals("sp")) {
					List<String> alist = br.lines().parallel()
					.skip(skip).collect(Collectors.toList());
					br.close();
					return alist.toArray(new String[0]);
				}
				System.gc();
			}finally{
				System.gc();
				br.close();
			}
		}

		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}

	// read only first line
	static public String readHeader(String filename, Integer skip) throws IOException{
		try(BufferedReader br = openFile(filename)){
			try{
				String line = br.lines().skip(skip).findFirst().get();
				br.close();
				System.gc();
				return line;
			} finally{
				br.close();
			}
		}
		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}

	static public Long lineCount2(String filename, String bench) throws IOException{
		try(BufferedReader br = openFile(filename)){

			if (bench.equals("s")){
				Long c = br.lines().count();
				br.close();
				return c;
			} else if (bench.equals("sp")) {
				Long c = br.lines().parallel().count();
				br.close();
				return c;
			}
			System.gc();
		}
		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}

	public static int lineCount(String filename) throws IOException {
		String fileExt = filename.substring(filename.lastIndexOf(".") + 1);
		InputStream is = null;
		if (fileExt.equals("gz")){
			FileInputStream fis = new FileInputStream(filename);
			GZIPInputStream gis = new GZIPInputStream(fis);
			is = new BufferedInputStream(gis);
		} else {
			is = new BufferedInputStream(new FileInputStream(filename));
		}

	    try {
	        byte[] c = new byte[1024];

	        int readChars = is.read(c);
	        if (readChars == -1) {
	            // bail out if nothing to read
	            return 0;
	        }

	        // make it easy for the optimizer to tune this loop
	        int count = 0;
	        while (readChars == 1024) {
	            for (int i=0; i<1024;) {
	                if (c[i++] == '\n') {
	                    ++count;
	                }
	            }
	            readChars = is.read(c);
	        }

	        // count remaining characters
	        while (readChars != -1) {
	            //System.out.println(readChars);
	            for (int i=0; i<readChars; ++i) {
	                if (c[i] == '\n') {
	                    ++count;
	                }
	            }
	            readChars = is.read(c);
	        }
	        return count == 0 ? 1 : count;
	    } finally {
	        is.close();
	    }
	}


	// compares the file lines with string term (can be regex) and returns those lines containing string term.
	static public char[] compare(String filename, String[] terms, String delim, Integer skip, String bench, Integer[] retrunCols) throws IOException {
		try(BufferedReader br = openFile(filename)) {

			Predicate<String> predicate = chainPredicates(terms);
			List<String> alist = new ArrayList<String> ();

			if (bench.equals("s")){
				if (retrunCols[0] == null){
					alist = br.lines()// asPredicate is supported in Java 8: otherwise use line -> line.matches(patt)
					.skip(skip).filter(predicate)
					.collect(Collectors.toList());
				} else {
					alist = br.lines()
					.skip(skip).filter(predicate)
					.map(s -> getCustomCols(s, delim, retrunCols))
					.collect(Collectors.toList());
				}
				br.close();
				System.gc();
				return alist.stream().collect(Collectors.joining(delim)).toCharArray();
			} else if (bench.equals("sp")) {
				if (retrunCols[0] == null){
					alist = br.lines().parallel() // asPredicate is supported in Java 8: otherwise use line -> line.matches(patt)
					.skip(skip).filter(predicate)
					.collect(Collectors.toList());
				} else {
					alist = br.lines().parallel()
					.skip(skip).filter(predicate)
					.map(s -> getCustomCols(s, delim, retrunCols))
					.collect(Collectors.toList());
				}
				br.close();
				System.gc();
				return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();
			}
		}
		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}


	// compares specific columns of a file with string term (can be regex) and returns those lines containing string term.
	public char[] compareToCols(String filename, String[] terms, String delim, Integer[] col, Integer skip, String bench, Integer[] retrunCols) throws IOException {
		try(BufferedReader br = openFile(filename)){

			Predicate<String> predicate = chainPredicates(terms);
			List<String> alist = new ArrayList<String> ();

			if (bench.equals("s")){
				if (retrunCols[0] == null){
					alist = br.lines()
					.skip(skip).filter(s -> toKeepWrapper(s, delim, predicate, col))
					.collect(Collectors.toList());
				} else{
					alist = br.lines()
					.skip(skip).filter(s -> toKeepWrapper(s, delim, predicate, col))
					.map(s -> getCustomCols(s, delim, retrunCols))
					.collect(Collectors.toList());
				}
				br.close();
				System.gc();
				return alist.stream().collect(Collectors.joining(delim)).toCharArray(); // System.getProperty("line.separator")

			} else if (bench.equals("sp")) {
				if (retrunCols[0] == null){
					alist = br.lines().parallel()
					.skip(skip).filter(s -> toKeepWrapper(s, delim, predicate, col))
					.collect(Collectors.toList());
				} else{
					alist = br.lines().parallel()
					.skip(skip).filter(s -> toKeepWrapper(s, delim, predicate, col))
					.map(s -> getCustomCols(s, delim, retrunCols))
					.collect(Collectors.toList());
				}
				br.close();
				System.gc();
				return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();
			}

		}
		catch(IOException e) {
			e.printStackTrace();
			}
		return null;
	}

// compares specific joined (_) columns of a file with string term (can be regex) and returns those lines containing string term.
	public char[] compareToJoinedCols(String filename, String[] terms, String delim, Integer[] col, Integer skip, String bench, Integer[] retrunCols, Integer chunk) throws IOException {
        try (final BufferedReader br = openFile(filename)) {
					Predicate<String> predicate = chainPredicates(terms);
					List<String> alist = new ArrayList<String> ();

					if (bench.equals("s")){
						if (retrunCols[0] == null){
							alist = br.lines()
							.skip(skip).filter(s -> toKeepWrapperJoint(s, delim, predicate, col))
							.collect(Collectors.toList());
						} else{
							alist = br.lines()
							.skip(skip).filter(s -> toKeepWrapperJoint(s, delim, predicate, col))
							.map(s -> getCustomCols(s, delim, retrunCols))
							.collect(Collectors.toList());
						}
						br.close();
						System.gc();
						return alist.stream().collect(Collectors.joining(delim)).toCharArray(); // System.getProperty("line.separator")

					} else if (bench.equals("sp")) {
						if (retrunCols[0] == null){
							alist = br.lines().parallel()
							.skip(skip).filter(s -> toKeepWrapperJoint(s, delim, predicate, col))
							.collect(Collectors.toList());
						} else{
							alist = br.lines().parallel()
							.skip(skip).filter(s -> toKeepWrapperJoint(s, delim, predicate, col))
							.map(s -> getCustomCols(s, delim, retrunCols))
							.collect(Collectors.toList());
						}
						br.close();
						System.gc();
						return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();

					} else if (bench.equals("cp")) { // chunk (slice) processing

						List<String> buffer = new ArrayList<>();
						String nextLine = null;
						int lineCtr = 1;
						do  {
				        buffer.clear();
				        for (int i=0; i < chunk; i++) {
				            if ((nextLine = br.readLine()) == null) break;
										// skip lines
										if (lineCtr++ <= skip) {
						            continue;
						        }
				            buffer.add(nextLine);
				        }
				        alist.addAll(buffer.stream().parallel()
								.filter(s -> toKeepWrapperJoint(s, delim, predicate, col))
								.map(s -> getCustomCols(s, delim, retrunCols))
								.collect(Collectors.toList()));
				    } while (nextLine != null);

						br.close();
						System.gc();
						return alist.stream().collect(Collectors.joining(delim)).toCharArray();
					}

				}
				catch(IOException e) {
					e.printStackTrace();
					}
				return null;
			}

	 // filter (of float type) based on the operator in term only within input columns
 	public char[] filterCol(String filename, String delim, Integer[] col, String term[], double[] cond, Integer skip, String bench, Integer[] retrunCols) throws IOException {
 		try(BufferedReader br = openFile(filename)){

			List<String> alist = new ArrayList<String> ();
			Map<String, BiPredicate<Double, Double>> operations = new HashMap<>();
			operations.put("gt", (a, b) -> a > b);
			operations.put("lt", (a, b) -> a < b);
			operations.put("eq", (a, b) -> Double.compare(a, b)  == 0); // more precise: Math.abs(checkDouble(a.split(delim)[col]) - b) <= Double.MIN_NORMAL
			operations.put("ge", (a, b) -> a >= b);
			operations.put("le", (a, b) -> a <= b);

 			//return alist.toArray(new String[0]);
			if (bench.equals("s")){
				if (retrunCols[0] == null){
					alist = br.lines().skip(skip)
					.filter(s -> toFilterWrapper(s, delim, col, cond, term, operations))
					.collect(Collectors.toList());
				} else {
					alist = br.lines().skip(skip)
					.filter(s -> toFilterWrapper(s, delim, col, cond, term, operations))
					.map(s -> getCustomCols(s, delim, retrunCols))
					.collect(Collectors.toList());
				}
				br.close();
				System.gc();
				return alist.stream().collect(Collectors.joining(delim)).toCharArray();

			} else if (bench.equals("sp")) {
				if (retrunCols[0] == null){
					alist = br.lines().parallel().skip(skip)
					.filter(s -> toFilterWrapper(s, delim, col, cond, term, operations))
					.collect(Collectors.toList());
				} else {
					alist = br.lines().parallel().skip(skip)
					.filter(s -> toFilterWrapper(s, delim, col, cond, term, operations))
					.map(s -> getCustomCols(s, delim, retrunCols))
					.collect(Collectors.toList());
				}
				br.close();
				System.gc();
				return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();
			}

 		}
 		catch(IOException e) {
 			e.printStackTrace();
 			}
 		return null;
 	}


 // both text(pattern) and numeric filtering
 public char[] compareFilterCol(String filename, Integer skip, String delim, String[] patt, Integer[] colT, String[] operation, Integer[] colN, double[] cond, String bench, Integer[] retrunCols) throws IOException {
 	try(BufferedReader br = openFile(filename)){

 		Predicate<String> predicate = chainPredicates(patt);
		List<String> alist = new ArrayList<String> ();
		Map<String, BiPredicate<Double, Double>> operations = new HashMap<>();
		operations.put("gt", (a, b) -> a > b);
		operations.put("lt", (a, b) -> a < b);
		operations.put("eq", (a, b) -> Double.compare(a, b)  == 0); // more precise: Math.abs(checkDouble(a.split(delim)[col]) - b) <= Double.MIN_NORMAL
		operations.put("ge", (a, b) -> a >= b);
		operations.put("le", (a, b) -> a <= b);

 		if (bench.equals("s")){

			if (retrunCols[0] == null){
				alist = br.lines().skip(skip)
				.filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
				.filter(s -> toKeepWrapper(s, delim, predicate, colT))
				.collect(Collectors.toList());
			} else{
				alist = br.lines().skip(skip)
				.filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
				.filter(s -> toKeepWrapper(s, delim, predicate, colT))
				.map(s -> getCustomCols(s, delim, retrunCols))
				.collect(Collectors.toList());
			}
			br.close();
			System.gc();
 			return alist.stream().collect(Collectors.joining(delim)).toCharArray();

 		} else if (bench.equals("sp")) {

			if (retrunCols[0] == null){
				alist = br.lines().parallel().skip(skip)
				.filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
				.filter(s -> toKeepWrapper(s, delim, predicate, colT))
				.collect(Collectors.toList());
			} else{
				alist = br.lines().parallel().skip(skip)
				.filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
				.filter(s -> toKeepWrapper(s, delim, predicate, colT))
				.map(s -> getCustomCols(s, delim, retrunCols))
				.collect(Collectors.toList());
			}
			br.close();
			System.gc();
 			return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();

 		}

 	}
 	catch(IOException e) {
 		e.printStackTrace();
 		}
 	return null;
 }

 // both text(pattern) and numeric filtering: each pattern search is performed on each col
 public char[] multiCompareFilterCol(String filename, Integer skip, String delim, String[] patt, Integer[] colT, String[] operation, Integer[] colN, double[] cond, String bench, Integer[] retrunCols) throws IOException {
	 try(BufferedReader br = openFile(filename)){
		 List<String> alist = new ArrayList<String> ();
		 Map<String, BiPredicate<Double, Double>> operations = new HashMap<>();
 		operations.put("gt", (a, b) -> a > b);
 		operations.put("lt", (a, b) -> a < b);
 		operations.put("eq", (a, b) -> Double.compare(a, b)  == 0); // more precise: Math.abs(checkDouble(a.split(delim)[col]) - b) <= Double.MIN_NORMAL
 		operations.put("ge", (a, b) -> a >= b);
 		operations.put("le", (a, b) -> a <= b);

		 if (bench.equals("s")){

			 if (retrunCols[0] == null){
				 alist = br.lines().skip(skip)
				 .filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
			   .collect(Collectors.toList());
			 } else{
				 alist = br.lines().skip(skip)
				 .filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
				 .map(s -> getCustomCols(s, delim, retrunCols))
			   .collect(Collectors.toList());
			 }
			 br.close();
			 System.gc();
			 return alist.stream().collect(Collectors.joining(delim)).toCharArray();

		 } else if (bench.equals("sp")) {

			 if (retrunCols[0] == null){
				 alist = br.lines().parallel().skip(skip)
				 .filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
			   .collect(Collectors.toList());
			 } else{
				 alist = br.lines().parallel().skip(skip)
				 .filter(s -> toFilterWrapper(s, delim, colN, cond, operation, operations))
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
				 .map(s -> getCustomCols(s, delim, retrunCols))
			   .collect(Collectors.toList());
			 }
			 br.close();
			 System.gc();
			 return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();

		 }
	 }
	 catch(IOException e) {
		 e.printStackTrace();
		 }
	 return null;
 }

 // text(pattern) matching: each pattern search is performed on each col (colT.length == patt.Length)
 public char[] multiCompareToCols(String filename, Integer skip, String delim, String[] patt, Integer[] colT, String bench, Integer[] retrunCols) throws IOException {
	 try(BufferedReader br = openFile(filename)){

		 List<String> alist = new ArrayList<String> ();

		 if (bench.equals("s")){

			 if (retrunCols[0] == null){
				 alist = br.lines().skip(skip)
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
			   .collect(Collectors.toList());
			 } else{
				 alist = br.lines().skip(skip)
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
				 .map(s -> getCustomCols(s, delim, retrunCols))
			   .collect(Collectors.toList());
			 }
			 br.close();
			 System.gc();
			 return alist.stream().collect(Collectors.joining(delim)).toCharArray();

		 } else if (bench.equals("sp")) {

			 if (retrunCols[0] == null){
				 alist = br.lines().parallel().skip(skip)
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
			   .collect(Collectors.toList());
			 } else{
				 alist = br.lines().parallel().skip(skip)
			 	 .filter(s -> toKeepWrapperSingle(s, delim, patt, colT))
				 .map(s -> getCustomCols(s, delim, retrunCols))
			   .collect(Collectors.toList());
			 }
			 br.close();
			 System.gc();
			 return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();

		 }
	 }
	 catch(IOException e) {
		 e.printStackTrace();
		 }
	 return null;
 }

	// get whole column (integer col) from a file.
	static public char[] getColumn(String filename, String delim, Integer[] cols, Integer skip, String bench, Integer[] rows, Integer chunk) throws IOException {
		try(BufferedReader br = openFile(filename)){
			List<String> alist = new ArrayList<String> ();
			if (rows[0] != null) { // return only specific rows and cols =============
				if (bench.equals("cp")) { // chunk (slice) processing ..................
					alist.add(br.lines().skip(skip + rows[0] - 1).findFirst().map(s -> getCustomCols(s, delim, cols)).get()); // first line index in rows
					List<String> buffer = new ArrayList<>();
					Boolean contMe = true;
					int ptr = 1;
					while (contMe){
							buffer.clear();
							for (int j=0; j < chunk; j++) {
								buffer.add(br.lines().skip(rows[ptr] - rows[ptr-1] -1).findFirst().get());
								ptr ++;
								if (ptr >= rows.length){ break;}
							}

							alist.addAll(buffer.stream().parallel()
							.map(s -> getCustomCols(s, delim, cols))
							.collect(Collectors.toList()));
							if (ptr >= rows.length){contMe = false;}
					}

					br.close();
					System.gc();
					return alist.stream().collect(Collectors.joining(delim)).toCharArray();

				} else { // sequential or parallel .....................................
					alist.add(br.lines().skip(skip + rows[0] - 1).findFirst().get()); // first line index in rows
					for (int i=1; i < rows.length; i++){
						alist.add(br.lines().skip(rows[i] - rows[i-1] -1).findFirst().get());
					}

					br.close();
					System.gc();
					if (bench.equals("s")){ // sequential...................................
						return alist.stream().map(s -> getCustomCols(s, delim, cols)).collect(Collectors.joining(delim)).toCharArray();
					} else if (bench.equals("sp")) { // parallel ...........................
						return alist.parallelStream().map(s -> getCustomCols(s, delim, cols)).collect(Collectors.joining(delim)).toCharArray();
					}
				}
			} else{ // return only specific columns ==================================
				if (bench.equals("s")){ // sequential...................................
					alist = br.lines()
					.skip(skip).map(s -> getCustomCols(s, delim, cols))
					.collect(Collectors.toList());
					br.close();
					System.gc();
					return alist.stream().collect(Collectors.joining(delim)).toCharArray();
				} else if (bench.equals("sp")) { // parallel ...........................
					alist = br.lines().parallel()
					.skip(skip).map(s -> getCustomCols(s, delim, cols))
					.collect(Collectors.toList());
					br.close();
					System.gc();
					return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();
			} else if (bench.equals("cp")) { // chunk (slice) processing .............
				List<String> buffer = new ArrayList<>();
				String nextLine = null;
				int lineCtr = 1;
				do  {
						buffer.clear();
						for (int i=0; i < chunk; i++) {
								if ((nextLine = br.readLine()) == null) break;
								if (lineCtr++ <= skip){
									 continue;}
								buffer.add(nextLine);
						}
						alist.addAll(buffer.stream().parallel()
						.map(s -> getCustomCols(s, delim, cols))
						.collect(Collectors.toList()));
				} while (nextLine != null);
				br.close();
				System.gc();
				return alist.stream().collect(Collectors.joining(delim)).toCharArray();
			}
		}}

		catch(IOException e) {
			e.printStackTrace();
		}
		return null;
	}


	// get whole column by processing each line in BufferedReader: this is a bit slower than getColumn
	static public char[] getColumnBuffer(String filename, String delim, Integer[] col, Integer skip, String bench) throws IOException {
		try(BufferedReader br = openFile(filename)){

			String newDelim = delim; // e.g. \t should be \\t

			/*
			if (delim.startsWith("\\")){
				newDelim = "@" + newDelim + "@"; // create a new unique delimiter
			}
			*/

			List<String> alist = new ArrayList<String> ();
			String text = "";
			int lineCtr = 1;
			while ((text = br.readLine()) != null) {

				// skip lines
				if (lineCtr++ <= skip) {
            continue;
        }
				String[] textIn = text.split(delim);
				//List<String> rowList = new ArrayList<String>();
				String[] rowList = new String[col.length];
				for (int i = 0; i < col.length; i++) {
						//rowList.add(textIn[col[i]]);
						rowList[i] = textIn[col[i]];
					}
				alist.add(String.join(newDelim, rowList));
			}

			br.close();
			System.gc();
			if (bench.equals("s")){
				return alist.stream().collect(Collectors.joining(delim)).toCharArray();
			} else if (bench.equals("sp")) {
   			return alist.parallelStream().collect(Collectors.joining(delim)).toCharArray();
			}

		}

		catch(IOException e) {
			e.printStackTrace();
		}
		return null;
	}

// read custom rows and columns only
public char[] getRowColumn(String filename, String delim, Integer[] cols, Integer[] rows, Integer skip, String bench, Integer chunk) throws IOException {
			try (final BufferedReader br = openFile(filename)) {
				List<String> alist = new ArrayList<String> ();


				//if (bench.equals("s")){
					alist.add(br.lines().skip(skip + rows[0] - 1).findFirst().get()); // first line index in rows
					for (int i=1; i < rows.length; i++){
						alist.add(br.lines().skip(rows[i] - rows[i-1] -1).findFirst().get());
					}
					br.close();
					System.gc();
					return alist.stream().map(s -> getCustomCols(s, delim, cols)).collect(Collectors.joining(delim)).toCharArray();
					// ????
			//	} else if (bench.equals("cp")){

				//	}
				}

			catch(IOException e) {
				e.printStackTrace();
				}
			return null;
		}

	// private methods ===========================================================
	// compile and combine all terms (can be regex) into a single predicate
	static private Predicate<String> chainPredicates(String[] terms){
		Set<Predicate<String>> combinedpredicates = new HashSet<>();
		for (int i = 0; i < terms.length; i++) {
			combinedpredicates.add(Pattern.compile(terms[i]).asPredicate());
		}
		 return combinedpredicates.stream()
									 .reduce(Predicate::or) // any true
									 .orElse(p -> true); // or true
	}

	private static boolean toKeepWrapper(String s, String delim, Predicate<String> predicate, Integer[] col){
		String[] line = s.split(delim);
		boolean tokeep = false;
		for (int i = 0; i < col.length; i++) {
			tokeep = tokeep | predicate.test(line[col[i]]);
		}
		//System.gc();
		return tokeep;
	 }

	 private static boolean toKeepWrapperJoint( String s, String delim, Predicate<String> predicate, Integer[] col) {
			String[] text = s.split(delim);
			String[] elements = new String[col.length];
			for (int i = 0; i < col.length; ++i) {
					elements[i] = text[col[i]];
			}
			return predicate.test(String.join("_", elements));
		}

	 private static boolean toKeepWrapperSingle(String s, String delim, String[] patt, Integer[] col){
		 String[] line = s.split(delim);
		 boolean tokeep = true;
		 for (int i = 0; i < col.length; i++){
			 Predicate<String> predicate = Pattern.compile(patt[i]).asPredicate();
			 tokeep = tokeep & predicate.test(line[col[i]]);
		 }
		 //System.gc();
		 return tokeep;
		}

		private static boolean toFilterWrapper(String s, String delim, Integer[] col, double[] cond, String[] term, Map<String, BiPredicate<Double, Double>> operations){
			String[] line = s.split(delim);
			boolean tokeep = true;
			for (int i = 0; i < col.length; i++){
				tokeep = tokeep & operations.get(term[i]).test(checkDouble(line[col[i]]), cond[i]);
			}
			//System.gc();
			return tokeep;
		}

		private static Double checkDouble(String s){
			try {return Double.parseDouble(s);} catch (NumberFormatException e) {return Double.NaN;}
		 }

	private static String getCustomCols(String s, String delim, Integer[] cols){
			String[] text = s.split(delim);
			//List<String> rowList = new ArrayList<String>();
			String[] rowList = new String[cols.length];
			for (int i = 0; i < cols.length; i++) {
				rowList[i] = text[cols[i]];
			}
			//System.gc();
			return String.join(delim, rowList);
	}

} // Class end
