function fujiplot(tab, opts)

% a wrapper for fujiplot.R function of M. Kanai: 
% https://github.com/mkanai/fujiplot
% 
% Note:
% To run circus on Windows, you need Perl.
% 1- Install Strawberry and add it to PATH.
% 2- run: perl PATH/to/circus -modules
% 3- install missing modeuls: cpan Font::TTF::Font
% 4- due to a bug, use M. Kanai's circos patch or directly his modified circos software.
% 
% Oveis Jamialahmadi, University of Gothenburg, February 2023.

arguments
    tab {mustBeA(tab, 'table')} % input GWAS summary stats with locus names for each trait
    opts.fujihome {mustBeFolder} = fullfile(fileparts(which("manplotter.m")), "dependencies", "fujiplot") % cloned from github.com/mkanai/fujiplot
    opts.circos {mustBeFile} = fullfile(fileparts(which("manplotter.m")), "dependencies/circos/circos-0.69-6-kanai/bin/circos")
    opts.outdir {mustBeTextScalar} = "output" % results will be saved to this directory
    opts.map (1,1) {mustBeMember(opts.map, ["jet", "turbo", "parula", "hot", "winter", "copper", "bone"])} = "turbo"
    opts.fontname {mustBeTextScalar} = "Garamond"
    opts.labelOnlyPleiotropic (1,1) logical = true % label only plietropic loci (inter trait loci), if false, shows all

    opts.backAlpha (1,1) double = 0.3
    opts.largePointSize (1,1) double = 16
    opts.smallPointSize (1,1) double = 8
    
    % data_tracks.conf options
    opts.label_size (1,1) double = 28 % lable font size in points
    opts.showstack (1,1) logical = true 

    % ideogram.config options
    opts.ideospace (1,1) double = 118.5 % between last and first chromosome

end

wd = fileparts(opts.outdir);
if isempty(wd) || wd == ""
    wd = pwd;
    opts.outdir = fullfile(wd, opts.outdir);
end
wd = string(wd);

% change label size of data_tracks ----------------------------------------
dt = readlines(fullfile(opts.fujihome, "config/data_tracks.conf"));
idx = dt.contains("label_size");
dt(idx) = regexprep(dt(idx), "\d*", string(opts.label_size));

% check stack plot
idx2 = find(dt.endsWith("data_tracks/stacked.txt"));
idx1 = find(~cellfun(@isempty, regexp(dt, "^(#|)(<plot>)")));
idx3 = find(~cellfun(@isempty, regexp(dt, "^(#|)(</plot>)")));
idxn = idx1 < idx2 & idx3 > idx2;
idx11 = idx1(idxn); idx33 = idx3(idxn);
dt(idx11:idx33) = regexprep(dt(idx11:idx33), "^#", "");
if ~opts.showstack
    dt(idx11:idx33) = "#" + dt(idx11:idx33);
end

% check highlights
idx2 = find(dt.endsWith("data_tracks/highlights.txt"));
idxn = idx1 < idx2 & idx3 > idx2;
idx11 = idx1(idxn); idx33 = idx3(idxn);
dt(idx11:idx33) = regexprep(dt(idx11:idx33), "^#", "");
if ~opts.showstack
    dt(idx11:idx33) = "#" + dt(idx11:idx33);
end

dt(dt == "") = [];
writelines(dt, fullfile(opts.fujihome, "config/data_tracks.conf"))

% change image.conf -------------------------------------------------------
dt = readlines(fullfile(opts.fujihome, "config/image.conf"));
idx = dt.startsWith(whitespacePattern + "dir");
tmpdir = extractAfter(dt(idx), "=");
dt(idx) = replace(dt(idx), tmpdir, opts.outdir);
dt(dt == "") = [];
writelines(dt, fullfile(opts.fujihome, "config/image.conf"))

% change ideogram.conf ----------------------------------------------------
dt = readlines(fullfile(opts.fujihome, "config/ideogram.conf"));
idx1 = find(dt.startsWith(whitespacePattern + "<pairwise"));
idx2 = find(dt.startsWith(whitespacePattern + "</pairwise>"));
ideospace = dt(idx1+1:idx2-1);
ideospace_val = ideospace.extractAfter("=");
ideospace = replace(ideospace, ideospace_val, opts.ideospace+"r");
dt(idx1+1:idx2-1) = ideospace;
dt(dt == "") = [];
writelines(dt, fullfile(opts.fujihome, "config/ideogram.conf"))

% check category column
if ~any(colnames(tab) == "CATEGORY")
    tab.CATEGORY = tab.TRAIT;
end

if isscalar(unique(tab.CATEGORY))
    tab.CATEGORY = tab.TRAIT;
end

% create color table
traits = tab(:, ["TRAIT", "CATEGORY"]);
traits = unique(traits, "rows");

catHex = rgb2hex(feval(opts.map, numel(unique(traits.CATEGORY))));
[~, idx] = ismember(traits.CATEGORY, unique(traits.CATEGORY, "stable"));
traits.COLOR = catHex(idx);

infile1 = fullfile(pwd, "input_fujuplot.txt");
infile2 = fullfile(pwd, "traits_fujiplot.txt");
writetable(tab, infile1, Delimiter="\t")
writetable(traits, infile2, Delimiter="\t")

cmd(1) = "script_dir <- '" + opts.fujihome.replace("\", "/") + "'";
cmd(2) = "library(dplyr)";
cmd(3) = "library(stringr)";
cmd(4) = 'CIRCOS_CONF = file.path(script_dir, "config", "circos.conf")';
cmd(5) = 'CIRCOS_PATH = "' + opts.circos.replace("\", "/") + '"';
cmd(6) = 'CIRCOS_DEBUG_GROUP = "summary"';
cmd(7) = "OUTPUT_BARPLOT = TRUE";
cmd(8) = "SCATTER_BACKGROUND_COLOR_ALPHA = " + opts.backAlpha;
cmd(9) = "LARGE_POINT_SIZE = " + opts.largePointSize;
cmd(10) = "SMALL_POINT_SIZE = " + opts.smallPointSize;

cmd(12) = "# intermediate files";
cmd(13) = 'COLOR_CONF = file.path(script_dir, "config", "color.conf")';
cmd(14) = 'SCATTER_BACKGROUND_CONF = file.path(script_dir, "config", "scatter_background.conf")';
cmd(15) = 'HIGHLIGHT_DATA = file.path(script_dir, "data_tracks", "highlights.txt")';
cmd(16) = 'SCATTER_DATA = file.path(script_dir, "data_tracks", "scatter.txt")';
cmd(17) = 'STACKED_DATA = file.path(script_dir, "data_tracks", "stacked.txt")';
cmd(18) = 'LABEL_DATA = file.path(script_dir, "data_tracks", "label.txt")';

cmd(19) = "setwd('" + wd.replace("\", "/") + "')";
cmd(20) = "df = as.data.frame(data.table::fread('" + infile1.replace("\", "/") + "', sep='\t'))";
cmd(21) = "traitlist = as.data.frame(data.table::fread('" + infile2.replace("\", "/") + "', sep='\t'))";

cmd(22) = "output_dir = '" + opts.outdir.replace("\", "/") + "'";
cmd(23) = "# helper func";
cmd(24) = "most_common = function(x) {tail(names(sort(table(x))), 1)}";
cmd(25) = "n_loci = length(unique(df$LOCUS_ID))";
cmd(27) = "if ( ! dir.exists(output_dir) ){";
cmd(28) = "  dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)}";

cmd(30) = "input_traits = traitlist$TRAIT";
cmd(31) = "traitlist = traitlist %>% filter(TRAIT %in% df$TRAIT) %>%";
cmd(32) = "  mutate(idx = 1:n(),";
cmd(33) = "         category_lower = str_replace_all(str_to_lower(CATEGORY), '[^a-z0-9_]', '_')) %>%";
cmd(34) = "  mutate(parameters = str_c('fill_color=', category_lower))";
cmd(35) = "excluded_traits = setdiff(input_traits, traitlist$TRAIT)";

cmd(37) = "# output color config";
cmd(38) = "str_c_comma = function(x){str_c(x, collapse = ',')}";
cmd(39) = "cols = traitlist %>% dplyr::select(category_lower, COLOR) %>%";
cmd(40) = "  unique() %>% mutate(rgb = apply(t(col2rgb(COLOR)), 1, str_c_comma),";
cmd(41) = "       rgba = apply(floor(t((1 - SCATTER_BACKGROUND_COLOR_ALPHA) * 255 + SCATTER_BACKGROUND_COLOR_ALPHA * col2rgb(COLOR))), 1, str_c_comma))";
cmd(42) = 'writeLines(c("<colors>",';
cmd(43) = '            sprintf("\t%s = %s\n\talpha_%s = %s", cols$category_lower, cols$rgb, cols$category_lower, cols$rgba),';
cmd(44) = '             "</colors>"), COLOR_CONF)';

cmd(46) = "# output scatterplot background config";
cmd(47) = "colsep = table(factor(traitlist$category_lower, levels=unique(traitlist$category_lower)))";
cmd(48) = "bg = data.frame(category_lower = unique(traitlist$category_lower),";
cmd(49) = "                y0 = nrow(traitlist) - cumsum(colsep) - 0.5,";
cmd(50) = "                y1 = nrow(traitlist) - cumsum(c(0,colsep))[1:length(colsep)] - 0.5)";
cmd(51) = 'writeLines(c("<backgrounds>",';
cmd(52) = '             sprintf("<background>\n\tcolor = alpha_%s\n\ty0 = %.1f\n\ty1 = %.1f\n</background>", bg$category_lower, bg$y0, bg$y1),';
cmd(53) = '             "</backgrounds>"), SCATTER_BACKGROUND_CONF)';

cmd(55) = "# output pleiotropy highlight data";
cmd(56) = "nsnps_per_locus = df %>% group_by(LOCUS_ID) %>% dplyr::summarize(n = n())";
cmd(57) = "df = df %>% mutate(CHR = str_c('hs', CHR),";
cmd(58) = "                   nsnps = nsnps_per_locus$n[match(LOCUS_ID, nsnps_per_locus$LOCUS_ID)])";
cmd(59) = "inter_categorical = df %>% group_by(LOCUS_ID) %>% dplyr::summarize(CHR = most_common(CHR),";
cmd(60) = "                                                            BP = most_common(BP),";
cmd(61) = "                                                            n = length(unique(CATEGORY))) %>% filter(n > 1)";
cmd(62) = 'write.table(inter_categorical[c("CHR", "BP", "BP")], HIGHLIGHT_DATA, sep = "\t", row.names = F, col.names = F, quote = F)';

cmd(64) = "# output outer scatter plot data";
cmd(65) = 'scatter = merge(df, traitlist, by = "TRAIT", all.x = T)';
cmd(66) = 'scatter$value = nrow(traitlist) - scatter$idx';
cmd(67) = "scatter$parameters = str_c(scatter$parameters, str_c('z=', scatter$nsnps), str_c('glyph_size=', ifelse(scatter$nsnps > 1, LARGE_POINT_SIZE, SMALL_POINT_SIZE)), sep = ',')";
cmd(68) = "scatter = scatter[order(scatter$nsnps, decreasing=T),]";
cmd(69) = 'write.table(scatter[c("CHR", "BP", "BP", "value", "parameters")], SCATTER_DATA, sep = "\t", row.names = F, col.names = F, quote = F)';

cmd(71) = "# output inner stacked scatter plot data";
cmd(72) = "stacked = list()";
cmd(73) = "stacked_y = rep(0, n_loci)";
cmd(74) = "names(stacked_y) = 1:n_loci";

cmd(76) = "for (i in 1:nrow(traitlist)) {";
cmd(77) = "  x = subset(scatter, idx == i)";
cmd(78) = "  x$value = stacked_y[x$LOCUS_ID]";
cmd(79) = "  stacked_y[x$LOCUS_ID] = stacked_y[x$LOCUS_ID] + 1";
cmd(80) = "  stacked[[i]] = x}";
cmd(81) = "stacked = do.call(rbind, stacked)";
cmd(82) = "stacked$parameters = str_c(stacked$parameters, str_c('z=', stacked$nsnps), sep = ',')";
cmd(83) = "stacked = stacked[order(stacked$nsnps, decreasing=T),]";
cmd(84) = 'write.table(stacked[c("CHR", "BP", "BP", "value", "parameters")], STACKED_DATA, sep = "\t", row.names = F, col.names = F, quote = F)';

cmd(86) = "# output label data";
if opts.labelOnlyPleiotropic
    cmd(87) = "label = df %>% filter(LOCUS_ID %in% inter_categorical$LOCUS_ID) %>%";
    cmd(88) = "  group_by(LOCUS_ID) %>%";
    cmd(89) = "  dplyr::summarize(CHR = most_common(CHR), BP = most_common(BP), GENE = most_common(GENE))";
else
    cmd(87) = "label = df %>%";
    cmd(88) = "  group_by(LOCUS_ID) %>%";
    cmd(89) = "  dplyr::summarize(CHR = most_common(CHR), BP = most_common(BP), GENE = most_common(GENE))";
end
cmd(90) = 'write.table(label[c("CHR", "BP", "BP", "GENE")], LABEL_DATA, sep = "\t", row.names = F, col.names = F, quote = F)';

cmd(92) = "# call circos";
if ispc
    [~, perl] = system("where perl");
    perl = strip(string(perl));
    perl = replace(perl, filesep, "/");
    cmd(93) = 'cmd = sprintf("' + perl + ' %s -conf %s %s", CIRCOS_PATH, CIRCOS_CONF, ifelse(CIRCOS_DEBUG_GROUP == "", "", sprintf("-debug_group %s", CIRCOS_DEBUG_GROUP)))';
else
    cmd(93) = 'cmd = sprintf("%s -conf %s %s", CIRCOS_PATH, CIRCOS_CONF, ifelse(CIRCOS_DEBUG_GROUP == "", "", sprintf("-debug_group %s", CIRCOS_DEBUG_GROUP)))';
end
% cmd(94) = "setwd(script_dir) # circos config files are specified with the relative paths";
cmd(95) = "system(cmd, wait=T)";

cmd(97) = "# clean-up the intermediate files";
cmd(98) = "for(f in c(COLOR_CONF, SCATTER_BACKGROUND_CONF, HIGHLIGHT_DATA, SCATTER_DATA, STACKED_DATA, LABEL_DATA)){";
cmd(99) = "  if (file.exists(f)) file.remove(f)}";

cmd(101) = "# output bar plot";
cmd(102) = "if (OUTPUT_BARPLOT) {";
cmd(103) = "  bar = df %>% group_by(TRAIT) %>%";
cmd(104) = "    dplyr::summarize(total = length(MARKER),";
cmd(105) = "              pleiotropic = length(MARKER[nsnps > 1]),";
cmd(106) = "              inter_categorical = length(MARKER[LOCUS_ID %in% inter_categorical$LOCUS_ID])) %>%";
cmd(107) = "    mutate(single = total - pleiotropic,";
cmd(108) = "           intra_categorical = pleiotropic - inter_categorical)";
cmd(109) = '  bar = merge(bar, traitlist, by = "TRAIT")';
cmd(110) = "  bar = bar[order(bar$idx, decreasing=T),]";
cmd(111) = "  rownames(bar) = bar$TRAIT";
cmd(112) = '  grDevices::cairo_pdf(file.path(output_dir, "barplot.pdf"), width = 8, height = 8, family = "Helvetica")';
cmd(113) = '  barplot(t(bar[,c("inter_categorical", "intra_categorical", "single")]), ylim = c(0, 100), space = 0, col = c("black", "grey50", "white"))';
cmd(114) = "  . = dev.off()}";

MATLAB2Rconnector("fujiplot.R", code=cmd');

delete(infile1)
delete(infile2)

% change fontname
if isfield(opts, 'fontname')
    svg = readlines(fullfile(opts.outdir, "circos.svg"));
    idx = svg.contains("font-family=");
    svg(idx) = regexprep(svg(idx), '(?<=font-family=")(.*?)(?=")', opts.fontname);
    if svg(end) == "", svg(end) = []; end
    writelines(svg, fullfile(opts.outdir, "circos.svg"))
end

end % END