#ifndef BGEN_REVISION_HPP
#define BGEN_REVISION_HPP
namespace globals {
	char const* bgen_version = "1.1.7" ;
	char const* const bgen_revision = "" ;
}
#endif
