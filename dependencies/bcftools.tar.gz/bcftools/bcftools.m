function pth = bcftools(opts)

% returns absolute path to qctool binary file
arguments
    opts.path {mustBeFolder} = fileparts(which("bcftools.m"))
    opts.unix (1,1) logical = true
end

fis = getfilenames(opts.path).x_;
fis = fis(startsWith(fis.lower, "bcftools") & ~contains(fis, "."));
fis = fis(1); % multiple versions?
pth = fullfile(opts.path, fis);

if opts.unix
    pth = makeWSLpath(pth);
end

end