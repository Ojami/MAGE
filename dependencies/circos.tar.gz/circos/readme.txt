To run circus on Windows, you need Perl.
1- Install Strawberry and add it to PATH.
2- run: perl PATH/to/circus -modules
3- install missing modeuls: cpan Font::TTF::Font